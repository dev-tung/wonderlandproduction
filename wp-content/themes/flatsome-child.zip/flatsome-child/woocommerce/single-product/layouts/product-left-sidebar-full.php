<?php echo do_shortcode('[buildingRender callback="buildingDetail"]'); ?>
